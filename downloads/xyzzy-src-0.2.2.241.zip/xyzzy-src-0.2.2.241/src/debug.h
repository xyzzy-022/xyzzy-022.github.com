#ifndef _debug_h_
# define _debug_h_

void
Debug(char *format, ...);

#endif /* _debug_h_ */
