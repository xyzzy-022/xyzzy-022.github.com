# extract.exe のビルド方法

  1. http://www.madobe.net/archiver/lib/unlha32.html から
     UNLHA32.LIB を入手
  2. src/etc/unlha 配下に UNLHA32.LIB をコピー
  3. projects/etc.sln を開いて ビルド
