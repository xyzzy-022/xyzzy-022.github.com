void gen_msg (int argc, char **argv);

const gensrc_action actions[] =
{
  {"gen-msg", gen_msg},
};
