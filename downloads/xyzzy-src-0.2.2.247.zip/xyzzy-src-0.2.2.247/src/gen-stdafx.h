#pragma once

#include "targetver.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cdecl.h"
#include "charset.h"
