#ifndef _debug_h_
# define _debug_h_

#include "cdecl.h"

void Debug (char *format, ...);
void Debug (const Char *b, size_t size);

#endif /* _debug_h_ */
