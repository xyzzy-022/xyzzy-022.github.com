#ifndef _XYZZY_CLIENT_H_
# define _XYZZY_CLIENT_H_

# define IDS_CONNECT_FAILED 1
# define IDS_CALL_PROCESS 2
# define IDS_NO_MEMORY 3
# define IDS_CREATE_THREAD 4
# define IDS_READ_FAILED 5

#endif
