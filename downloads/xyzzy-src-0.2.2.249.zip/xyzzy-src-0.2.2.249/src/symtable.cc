#include "stdafx.h"
#define EXTERN /* empty */
#include "ed.h"
#include "symtable.h"

#include "gen/symtable.cc"
